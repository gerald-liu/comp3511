#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
	pid_t pid;
	int pipefd[2];
	char buffer[128];

	pipe(pipefd);
	pid = fork();

	if (pid == 0){		// child process
		dprintf(pipefd[1], "Hello! This is your child!\n");
		printf("Child finished.\n");
	}
	else if (pid > 0){	// parent process
		wait(NULL);
		read(pipefd[0], buffer, 128);
		printf(buffer);
		printf("Parent finished.\n");
	}
}
