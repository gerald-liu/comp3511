#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define MAX_IN 1024
#define MAX_IN_2 2048
void map(int n, int *input, pthread_t *threads);
unsigned reduce(int n, pthread_t *threads);
void *map_runner(void *);
void *reduce_runner(void *);
struct reduce_arg{
  pthread_t *a;
  pthread_t *b;
};

int main(int argc, char **argv){
  unsigned int n;
  int i;
  unsigned long long sum;
  unsigned int input[MAX_IN];
  pthread_t threads[MAX_IN];

  n = strtoul(argv[1], NULL, 10);
  n += 1;
  for (i = 0; i < n; ++i){
    input[i] = i;
  }

  map(n, input, threads);
  sum = reduce(n, threads);

  printf("sum of squares: %llu\n", sum);  
}

void map(int n, int *input, pthread_t *threads){
  int i;
  void *ret;
  for (i = 0; i < n; ++i){
    pthread_create(&(threads[i]), NULL, map_runner, input[i]);
  }
}

unsigned reduce(int n, pthread_t *threads){
  int i, j, k;
  void *ret;
  pthread_t reduce_threads[MAX_IN_2];
  struct reduce_arg rargs[MAX_IN_2];

  j = 0;
  k = 0;
  while(n > 1){
    for (i = 0; i < n/2; ++i){
      rargs[j].a = &(threads[2*i]);
      rargs[j].b = &(threads[2*i + 1]);

      pthread_create(&(reduce_threads[j]), NULL, reduce_runner, &(rargs[j]));
      ++j;
    }
    if (n%2){
      memcpy(&(reduce_threads[j]), &(threads[n - 1]), sizeof(pthread_t));
      ++j;
    }
    n = j - k;
    threads = reduce_threads + k;
    k = j;
  }
  pthread_join(threads[0], &ret);
  return ret;
}

void *map_runner(void *arg){
  int i;

  i = arg;
  printf("map %d to %d\n", i, i*i);
  return i*i;
}

void *reduce_runner(void *arg){
  void *a;
  void *b;
  struct reduce_arg *argp = arg;

  pthread_join(*(argp->a), &a);
  pthread_join(*(argp->b), &b);
  printf("reduce %u and %u to %u\n", (unsigned)a, (unsigned)b, (unsigned)a + (unsigned)b);

  return (unsigned)a + (unsigned)b;
}
